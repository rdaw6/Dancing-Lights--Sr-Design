import sacn
import time
import sys
import math

# 0.03 for very gradual, 0.01 for medium, 0.005 for quick
wait = float(sys.argv[1])
numArgs = len(sys.argv)

sender = sacn.sACNsender()
sender.start()
sender.bind_address = '169.254.149.221'
sender.activate_output(16)
sender.activate_output(20)
sender[16].multicast = True
sender[20].multicast = True
#sender.manual_flush = True
temp = eval(sys.argv[2])
for x in range(3, numArgs):
    new = temp + eval(sys.argv[x])
    temp = new
while True:
    new2 = new[3:] + new[:3]
    new = new2
    sender[16].dmx_data = new2 * math.ceil(54/(numArgs-2))
    sender[20].dmx_data = new2 * math.ceil(27/(numArgs-2))    
    time.sleep(wait)
sender.stop()

