import sacn
import time
import sys

# 0.03 for very gradual, 0.01 for medium, 0.005 for quick
if len(sys.argv) == 2:
    wait = float(sys.argv[1])
    run = True
else:
    print("Invalid input for delay command")
    run = False
sender = sacn.sACNsender()
sender.start()
sender.bind_address = '169.254.149.221'
sender.activate_output(16)
sender.activate_output(20)
sender[16].multicast = True
sender[20].multicast = True
#sender.manual_flush = True
while run:
    for x in range(256):
        t = (255, x, 0)
        sender[16].dmx_data = t*54
        sender[20].dmx_data = t*27
        time.sleep(wait)
    for x in range(256):
        t = (255-x, 255, 0)
        sender[16].dmx_data = t*54
        sender[20].dmx_data = t*27
        time.sleep(wait)
    for x in range(256):
        t = (0, 255, x)
        sender[16].dmx_data = t*54
        sender[20].dmx_data = t*27
        time.sleep(wait)
    for x in range(256):
        t = (0, 255-x, 255)
        sender[16].dmx_data = t*54
        sender[20].dmx_data = t*27
        time.sleep(wait)
    for x in range(256):
        t = (x, 0, 255)
        sender[16].dmx_data = t*54
        sender[20].dmx_data = t*27
        time.sleep(wait)
    for x in range(256):
        t = (255, 0, 255-x)
        sender[16].dmx_data = t*54
        sender[20].dmx_data = t*27
        time.sleep(wait)
sender.stop()

