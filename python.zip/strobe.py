import sacn
import time
import sys

# 0.03 for very gradual, 0.01 for medium, 0.005 for quick
wait = float(sys.argv[1])
numArgs = len(sys.argv)

sender = sacn.sACNsender()
sender.start()
sender.bind_address = '169.254.149.221'
sender.activate_output(16)
sender.activate_output(20)
sender[16].multicast = True
sender[20].multicast = True
#sender.manual_flush = True
while True:
    for x in range(2, numArgs):
        t = eval(sys.argv[x])
        sender[16].dmx_data = t*54
        sender[20].dmx_data = t*27
        time.sleep(wait)
sender.stop()

