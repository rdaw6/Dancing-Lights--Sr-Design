import sacn
import time
import sys
import math

# 0.03 for very gradual, 0.01 for medium, 0.005 for quick
wait = float(sys.argv[1])
numArgs = len(sys.argv)
base = eval(sys.argv[2])
high = eval(sys.argv[3])

sender = sacn.sACNsender()
sender.start()
sender.bind_address = '169.254.149.221'
sender.activate_output(16)
sender.activate_output(20)
sender[16].multicast = True
sender[20].multicast = True
#sender.manual_flush = True
numLEDs = int(54/3)

while True:
    for x in range(numLEDs):
        t = base*x + high + base*(numLEDs-x-1)
        sender[16].dmx_data = t
        sender[20].dmx_data = t
        time.sleep(wait)
    for x in range(numLEDs):
        t = base*(numLEDs-x-1) + high + base*x
        sender[16].dmx_data = t
        sender[20].dmx_data = t
        time.sleep(wait)
sender.stop()

