import sacn
import time

sender = sacn.sACNsender()
sender.start()
sender.bind_address = '169.254.149.221'
sender.activate_output(16)
sender.activate_output(20)
sender[16].multicast = True
sender[20].multicast = True
sender.manual_flush = True
while True:
    sender[16].dmx_data = (255,)*54
    sender[20].dmx_data = (255,)*54
    sender.flush()
    time.sleep(0.1)
    sender[16].dmx_data = (0,)*54
    sender[20].dmx_data = (0,)*54
    sender.flush()
    time.sleep(0.1)
sender.stop()

